local armor_slots = {}
local timer = 0

-- Přesný výpočet výdrže přímo z wear hodnoty v Luanti/Mineclonii
local function get_durability_info(stack)
	if not stack or stack:is_empty() then
		return nil, nil
	end

	local wear = stack:get_wear()
	-- Pokud je wear 0, brnění je zcela nové (100% výdrž)
	if wear <= 0 then
		return 1.0, nil
	end

	-- V Luanti je wear vždy v rozsahu 0 (nové) až 65535 (rozbité)
	local ratio = math.max(0, math.min(1, (65535 - wear) / 65535))

	-- Zjištění maximálního počtu použití pro přesný výpočet posledních 10 bodů
	local def = stack:get_definition()
	local max_uses = (def and def._mcl_uses) or (def and def.groups and def.groups.armor_uses) or 0

	local remaining = nil
	if max_uses > 0 then
		remaining = math.ceil(max_uses * ratio)
	else
		-- Záložní výpočet, pokud předmět nemá definované _mcl_uses (cca 2 % výdrže)
		remaining = math.ceil(500 * ratio)
	end

	return ratio, remaining
end

-- Pozadí slotu: průhledné za normálního stavu, červené při posledních 10 bodech
local function make_slot_bg(is_low)
	if is_low then
		return "[combine:42x42^[noalpha^[colorize:#AA0000:255"
	else
		return "[combine:1x1"
	end
end

-- Vytvoření 4 slotů v řádku vlevo od totemu
local function init_player_hud(player)
	local name = player:get_player_name()
	if armor_slots[name] then
		return
	end

	armor_slots[name] = {}

	local totem_left_edge = -340
	local spacing = 46
	local base_y = -48

	for i = 1, 4 do
		local x_pos = totem_left_edge - ((5 - i) * spacing)

		armor_slots[name][i] = {
			bg = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos, y = base_y },
				alignment = { x = 1, y = 1 },
				scale = { x = 1, y = 1 },
				text = "[combine:1x1",
				z_index = 0,
			}),
			icon = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos + 5, y = base_y + 5 },
				alignment = { x = 1, y = 1 },
				scale = { x = 2, y = 2 },
				text = "[combine:1x1",
				z_index = 1,
			}),
			bar_bg = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos + 5, y = base_y + 34 },
				alignment = { x = 1, y = 1 },
				scale = { x = 1, y = 1 },
				text = "[combine:1x1",
				z_index = 2,
			}),
			bar = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos + 5, y = base_y + 34 },
				alignment = { x = 1, y = 1 },
				scale = { x = 1, y = 1 },
				text = "[combine:1x1",
				z_index = 3,
			}),
		}
	end
end

-- Zjištění správného slotu pro každou část brnění
local function get_armor_stacks(inv)
	local result = { ItemStack(), ItemStack(), ItemStack(), ItemStack() }
	local size = inv:get_size("armor")

	for s = 1, size do
		local st = inv:get_stack("armor", s)
		if st and not st:is_empty() then
			local def = st:get_definition()
			local groups = (def and def.groups) or {}
			if groups.armor_head then
				result[1] = st
			elseif groups.armor_torso then
				result[2] = st
			elseif groups.armor_legs then
				result[3] = st
			elseif groups.armor_feet then
				result[4] = st
			end
		end
	end
	return result
end

-- Pravidelná aktualizace HUDu
minetest.register_globalstep(function(dtime)
	timer = timer + dtime
	if timer < 0.25 then
		return
	end
	timer = 0

	for _, player in ipairs(minetest.get_connected_players()) do
		local name = player:get_player_name()
		local inv = player:get_inventory()
		local slots = armor_slots[name]

		if inv and slots then
			local armor_list = get_armor_stacks(inv)

			for i = 1, 4 do
				local stack = armor_list[i]
				local hud = slots[i]

				if not stack or stack:is_empty() then
					player:hud_change(hud.bg, "text", "[combine:1x1")
					player:hud_change(hud.icon, "text", "[combine:1x1")
					player:hud_change(hud.bar_bg, "text", "[combine:1x1")
					player:hud_change(hud.bar, "text", "[combine:1x1")
				else
					local def = stack:get_definition()
					local meta = stack:get_meta()

					local tex = meta:get_string("inventory_image")
					if tex == "" then
						tex = (def and def.inventory_image) or "[combine:1x1"
					end

					local ratio, rem = get_durability_info(stack)

					player:hud_change(hud.icon, "text", tex)
					player:hud_change(hud.bg, "text", make_slot_bg(rem ~= nil and rem <= 10))

					-- Pokud je brnění jakkoliv poškozené (ratio < 1.0), vykreslíme proužek
					if ratio and ratio < 1.0 then
						local width = math.max(1, math.floor(32 * ratio))
						local color = "#00FF00"
						if ratio < 0.5 then color = "#FFFF00" end
						if ratio < 0.25 or (rem and rem <= 10) then color = "#FF0000" end

						player:hud_change(hud.bar_bg, "text", "[combine:32x4^[noalpha^[colorize:#000000:255")
						player:hud_change(hud.bar, "text", "[combine:" .. width .. "x3^[noalpha^[colorize:" .. color .. ":255")
					else
						player:hud_change(hud.bar_bg, "text", "[combine:1x1")
						player:hud_change(hud.bar, "text", "[combine:1x1")
					end
				end
			end
		end
	end
end)

minetest.register_on_joinplayer(function(player)
	minetest.after(0.5, function()
		if player and player:is_player() then
			init_player_hud(player)
		end
	end)
end)

minetest.register_on_leaveplayer(function(player)
	local name = player:get_player_name()
	armor_slots[name] = nil
end)
