INSTALACE MODU MUJ OSTEP (MINETEST / LUANTI)
=============================================
1. Rozbalte slozku 'muj_ostep' z tohoto ZIP archivu.
2. Vlozte celou slozku 'muj_ostep' do slozky 'mods' ve vasem Minetest / Luanti (nebo do 'worlds/<nazev_sveta>/worldmods/').
3. Spustte hru, vyberte svuj svet -> Nastavit (Configure) -> najdete 'Muj Ostep (Spear)' a kliknete na Povolit (Enable).
4. Ulozte a spustte hru.

OVLADANI A FUNKCE:
- Leve tlacitko: Bodnuti na dalku (dosah 2.0 az 4.5 bloku).
- Prave tlacitko na moba: Okamzity zasah zblizka.
- Prave tlacitko do vzduchu / na zem: Lunge (rychly vypad vpred).
- Prave tlacitko behem letu s Elytrou: Raketove zrychleni ve smeru pohledu.
- Kompatibilita: Automaticky rozpoznava Mineclonia/VoxeLibre i zakladni Minetest Game.
