-- Detekce aktivni hry (Mineclonia vs Minetest Game)
local has_mcl = minetest.get_modpath("mcl_core") ~= nil
local has_default = minetest.get_modpath("default") ~= nil

-- 1. DEFINICE STATISTIK PRO VARIANTY OSTEPU
local spear_materials = {
    wood = {
        desc = "Dreveny ostep",
        mcl_mat = "mcl_core:wood",
        mtg_mat = "group:wood",
        jab_interval = 0.95,
        jab_damage = 3,
        charge_mult = 0.7,
        durability = 59,
        enchant_val = 15
    },
    stone = {
        desc = "Kamenny ostep",
        mcl_mat = "mcl_core:cobble",
        mtg_mat = "group:stone",
        jab_interval = 1.0,
        jab_damage = 4,
        charge_mult = 0.82,
        durability = 131,
        enchant_val = 5
    },
    copper = {
        desc = "Medeny ostep",
        mcl_mat = "mcl_core:copper_ingot",
        mtg_mat = "default:copper_ingot",
        jab_interval = 1.05,
        jab_damage = 4,
        charge_mult = 0.85,
        durability = 190,
        enchant_val = 9
    },
    iron = {
        desc = "Zelezny ostep",
        mcl_mat = "mcl_core:iron_ingot",
        mtg_mat = "default:steel_ingot",
        jab_interval = 1.1,
        jab_damage = 5,
        charge_mult = 0.95,
        durability = 250,
        enchant_val = 14
    },
    gold = {
        desc = "Zlaty ostep",
        mcl_mat = "mcl_core:gold_ingot",
        mtg_mat = "default:gold_ingot",
        jab_interval = 0.9,
        jab_damage = 3,
        charge_mult = 0.7,
        durability = 32,
        enchant_val = 22
    },
    diamond = {
        desc = "Diamantovy ostep",
        mcl_mat = "mcl_core:diamond",
        mtg_mat = "default:diamond",
        jab_interval = 1.15,
        jab_damage = 6,
        charge_mult = 1.075,
        durability = 1561,
        enchant_val = 10
    },
    netherite = {
        desc = "Netheritovy ostep",
        mcl_mat = nil,
        mtg_mat = nil,
        jab_interval = 1.2,
        jab_damage = 7,
        charge_mult = 1.2,
        durability = 2031,
        enchant_val = 15
    }
}

-- FUNKCE PRO UDELENI DAMAGE
local function deal_damage(user, target, damage, interval)
    if not target or not user then return end

    local itemstack = user:get_wielded_item()
    local meta = itemstack:get_meta()
    local sharpness_lvl = meta:get_int("enchantment_sharpness") or 0
    local bonus = 0
    if sharpness_lvl > 0 then
        bonus = sharpness_lvl * 0.5 + 0.5
    end

    target:punch(user, 1.0, {
        full_punch_interval = interval,
        damage_groups = {fleshy = damage + math.floor(bonus)}
    }, nil)

    if has_mcl then
        minetest.sound_play("mcl_bow_hit", {pos = user:get_pos(), gain = 0.8}, true)
    end
end

-- FUNKCE PRO PROVEDENI DASH / LUNGE (I PRO ELYTRU)
local function execute_lunge(itemstack, user, stats)
    local p_name = user:get_player_name()
    local dir = user:get_look_dir()

    local is_gliding = false
    if minetest.global_exists("mcl_elytra") and mcl_elytra.is_flying then
        is_gliding = mcl_elytra.is_flying(user)
    end

    if is_gliding then
        user:add_player_velocity({
            x = dir.x * 35,
            y = dir.y * 35,
            z = dir.z * 35
        })
    else
        user:add_player_velocity({
            x = dir.x * 24,
            y = (dir.y * 12) + 7.5,
            z = dir.z * 24
        })
    end

    if has_mcl then
        minetest.sound_play("mcl_bow_strict", {pos = user:get_pos(), gain = 1.0}, true)
        minetest.add_particlespawner({
            amount = 20, time = 0.1,
            minpos = user:get_pos(), maxpos = user:get_pos(),
            minvel = {x = -2, y = 0.1, z = -2}, maxvel = {x = 2, y = 1, z = 2},
            minexptime = 0.4, maxexptime = 0.8, minsize = 1, maxsize = 3,
            texture = "mcl_particles_smoke.png",
        })
    end

    if not minetest.is_creative_enabled(p_name) then
        itemstack:add_wear(65535 / (stats.durability / 3))
    end
    return itemstack
end

-- 2. REGISTRACE VSECH VARIANT OSTEPU
for name, stats in pairs(spear_materials) do
    local item_name = "muj_ostep:spear_" .. name
    local texture_file = "muj_ostep_" .. name .. ".png"

    minetest.register_tool(item_name, {
        description = stats.desc,
        inventory_image = texture_file,
        wield_image = texture_file,

        tool_capabilities = {
            full_punch_interval = stats.jab_interval,
            max_drop_level = 0,
            groupcaps = {},
            damage_groups = {fleshy = stats.jab_damage},
        },
        groups = {
            weapon = 1,
            sword = 1,
            spear = 1,
            combat_element = 1,
            enchantable = 1,
            enchantability = stats.enchant_val
        },

        -- Leve tlacitko: Jab utok na dalku (2.0 - 4.5 bloku)
        on_use = function(itemstack, user, pointed_thing)
            if pointed_thing.type ~= "object" then return itemstack end
            local target = pointed_thing.ref
            local distance = vector.distance(user:get_pos(), target:get_pos())

            if distance < 2.0 or distance > 4.5 then return itemstack end

            deal_damage(user, target, stats.jab_damage, stats.jab_interval)

            if not minetest.is_creative_enabled(user:get_player_name()) then
                itemstack:add_wear(65535 / stats.durability)
            end
            return itemstack
        end,

        -- Prave tlacitko do vzduchu
        on_secondary_use = function(itemstack, user, pointed_thing)
            return execute_lunge(itemstack, user, stats)
        end,

        -- Prave tlacitko na bloky a entity
        on_place = function(itemstack, placer, pointed_thing)
            if pointed_thing and pointed_thing.type == "object" then
                local target = pointed_thing.ref
                if target and target ~= placer then
                    deal_damage(placer, target, stats.jab_damage, stats.jab_interval)

                    if not minetest.is_creative_enabled(placer:get_player_name()) then
                        itemstack:add_wear(65535 / stats.durability)
                    end
                    return itemstack
                end
            end

            return execute_lunge(itemstack, placer, stats)
        end
    })

    -- Recepty pro Mineclonia
    if has_mcl and stats.mcl_mat then
        minetest.register_craft({
            output = item_name,
            recipe = {
                {"", "", stats.mcl_mat},
                {"", "mcl_core:stick", ""},
                {"mcl_core:stick", "", ""},
            }
        })
    end

    -- Recepty pro klasicky Minetest Game
    if has_default and stats.mtg_mat then
        minetest.register_craft({
            output = item_name,
            recipe = {
                {"", "", stats.mtg_mat},
                {"", "default:stick", ""},
                {"default:stick", "", ""},
            }
        })
    end
end

-- 3. RECEPTY PRO NETHERITE
if has_mcl then
    minetest.register_craft({
        type = "shapeless",
        output = "muj_ostep:spear_netherite",
        recipe = {"muj_ostep:spear_diamond", "mcl_netherite:netherite_ingot"},
    })
elseif has_default then
    -- V zakladnim Minetestu lze vyrobit z diamantu a mese krystalu
    minetest.register_craft({
        type = "shapeless",
        output = "muj_ostep:spear_netherite",
        recipe = {"muj_ostep:spear_diamond", "default:mese_crystal"},
    })
end
