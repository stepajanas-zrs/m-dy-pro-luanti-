local armor_slots = {}
local timer = 0

-- Vypocet vydrze pro Minetest Game + 3d_armor (wear 0 = 100%, 65535 = 0%)
local function get_durability_info(stack)
	if not stack or stack:is_empty() then
		return nil, nil
	end

	local wear = stack:get_wear()
	if wear <= 0 then
		return 1.0, nil
	end

	local ratio = math.max(0, math.min(1, (65535 - wear) / 65535))
	local def = stack:get_definition()
	local max_uses = (def and def.groups and def.groups.armor_use) or 0

	local remaining = nil
	if max_uses > 0 then
		-- V 3d_armor udava armor_use opotrebeni za 1 zasah (z 65535)
		local total_hits = math.floor(65535 / max_uses)
		remaining = math.ceil(total_hits * ratio)
	else
		remaining = math.ceil(500 * ratio)
	end

	return ratio, remaining
end

-- Pozadi slotu: pruhledne za normalniho stavu, cervene pri poslednich 10 bodech vydrze
local function make_slot_bg(is_low)
	if is_low then
		return "[combine:42x42^[noalpha^[colorize:#AA0000:255"
	else
		return "[combine:1x1"
	end
end

-- Vytvoreni 4 slotu v radku vlevo od hotbaru (v MTG neni totem, hotbar ma 8 slotu)
local function init_player_hud(player)
	local name = player:get_player_name()
	if armor_slots[name] then
		return
	end

	armor_slots[name] = {}

	-- V MTG konci 8-slotovy hotbar cca na -215 px od stredu
	local hotbar_left_edge = -230
	local spacing = 46
	local base_y = -48

	for i = 1, 4 do
		local x_pos = hotbar_left_edge - ((5 - i) * spacing)

		armor_slots[name][i] = {
			bg = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos, y = base_y },
				alignment = { x = 1, y = 1 },
				scale = { x = 1, y = 1 },
				text = "[combine:1x1",
				z_index = 0,
			}),
			icon = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos + 5, y = base_y + 5 },
				alignment = { x = 1, y = 1 },
				scale = { x = 2, y = 2 },
				text = "[combine:1x1",
				z_index = 1,
			}),
			bar_bg = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos + 5, y = base_y + 34 },
				alignment = { x = 1, y = 1 },
				scale = { x = 1, y = 1 },
				text = "[combine:1x1",
				z_index = 2,
			}),
			bar = player:hud_add({
				type = "image",
				position = { x = 0.5, y = 1 },
				offset = { x = x_pos + 5, y = base_y + 34 },
				alignment = { x = 1, y = 1 },
				scale = { x = 1, y = 1 },
				text = "[combine:1x1",
				z_index = 3,
			}),
		}
	end
end

-- Nacteni brneni z detached inventare 3d_armor ("<jmeno>_armor")
local function get_armor_stacks(player)
	local result = { ItemStack(), ItemStack(), ItemStack(), ItemStack() }
	local name = player:get_player_name()
	local armor_inv = minetest.get_inventory({ type = "detached", name = name .. "_armor" })

	if not armor_inv then
		armor_inv = player:get_inventory()
	end
	if not armor_inv then
		return result
	end

	local list_name = armor_inv:get_size("armor") > 0 and "armor" or nil
	if not list_name then
		return result
	end

	local size = armor_inv:get_size(list_name)
	for s = 1, size do
		local st = armor_inv:get_stack(list_name, s)
		if st and not st:is_empty() then
			local def = st:get_definition()
			local groups = (def and def.groups) or {}
			if groups.armor_head then
				result[1] = st
			elseif groups.armor_torso then
				result[2] = st
			elseif groups.armor_legs then
				result[3] = st
			elseif groups.armor_feet then
				result[4] = st
			end
		end
	end
	return result
end

-- Pravidelna aktualizace HUDu
minetest.register_globalstep(function(dtime)
	timer = timer + dtime
	if timer < 0.25 then
		return
	end
	timer = 0

	for _, player in ipairs(minetest.get_connected_players()) do
		local name = player:get_player_name()
		local slots = armor_slots[name]

		if slots then
			local armor_list = get_armor_stacks(player)

			for i = 1, 4 do
				local stack = armor_list[i]
				local hud = slots[i]

				if not stack or stack:is_empty() then
					player:hud_change(hud.bg, "text", "[combine:1x1")
					player:hud_change(hud.icon, "text", "[combine:1x1")
					player:hud_change(hud.bar_bg, "text", "[combine:1x1")
					player:hud_change(hud.bar, "text", "[combine:1x1")
				else
					local def = stack:get_definition()
					local meta = stack:get_meta()

					local tex = meta:get_string("inventory_image")
					if tex == "" then
						tex = (def and def.inventory_image) or "[combine:1x1"
					end

					local ratio, rem = get_durability_info(stack)

					player:hud_change(hud.icon, "text", tex)
					player:hud_change(hud.bg, "text", make_slot_bg(rem ~= nil and rem <= 10))

					if ratio and ratio < 1.0 then
						local width = math.max(1, math.floor(32 * ratio))
						local color = "#00FF00"
						if ratio < 0.5 then color = "#FFFF00" end
						if ratio < 0.25 or (rem and rem <= 10) then color = "#FF0000" end

						player:hud_change(hud.bar_bg, "text", "[combine:32x4^[noalpha^[colorize:#000000:255")
						player:hud_change(hud.bar, "text", "[combine:" .. width .. "x3^[noalpha^[colorize:" .. color .. ":255")
					else
						player:hud_change(hud.bar_bg, "text", "[combine:1x1")
						player:hud_change(hud.bar, "text", "[combine:1x1")
					end
				end
			end
		end
	end
end)

minetest.register_on_joinplayer(function(player)
	minetest.after(0.5, function()
		if player and player:is_player() then
			init_player_hud(player)
		end
	end)
end)

minetest.register_on_leaveplayer(function(player)
	local name = player:get_player_name()
	armor_slots[name] = nil
end)
